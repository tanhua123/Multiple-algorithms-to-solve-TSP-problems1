%IA algorithm
clear;
close;
clc;

%% 初始化
% C = importdata('C:\Users\zhangchuang\Desktop\处理测试函数\ch130.mat');
C=[1304,2312;3639,1315;4177,2244;3712,1399;3488,1535;
     3326,1556;3238,1229;4196,1044;4312,790;  4386,570  ;
     3007,1970;2562,1756;2788,1491;2381,1676;1332,695  ;
     3715,1678;3918,2179;4061,2370;3780,2212;3676,2578;
     4029,2838;4263,2931;3429,1908;3507,2376;3394,2643;
     3439,3201;2935,3240;3140,3550;2545,2357;2778,2826;
     2370,2975];     %城市坐标
N=size(C,1); %TSP问题的规模，即城市数目
D=zeros(N);  %任意两个城市距离间隔矩阵

for i=1:N
    for j=1:N
        D(i,j)=((C(i,1)-C(j,1))^2+(C(i,2)-C(j,2))^2)^0.5;
    end
end  
 
NP=50;  %免疫样本数目
G=1000; %最大免疫迭代代数
f=zeros(N,NP); %用于存储种群

for i=1:NP
    f(:,i)=randperm(N); %随机生成初始种群
end
  
len=zeros(NP,1); %存储路径长度
for i=1:NP
    len(i)=luJingChang(D,f(:,i),N); %计算路径长度
end
  
[Sortlen,Index]=sort(len);
Sortf=f(:,Index); %种群个体排序
Nc1=10; %克隆个数
trace = zeros(1,G);

  
%% 迭代
for gen = 1:G
    %% 选亲和度前一半进行免疫操作
    af = zeros(N,NP/2);
    alen = zeros(1,NP/2);
    for i=1:NP/2
        a=Sortf(:,i);
        Ca=repmat(a,1,Nc1); %前一半克隆
        for j=1:Nc1
            p = randperm(N);%元素的交换           
            temp=Ca(p(1),j);
            Ca(p(1),j)=Ca(p(2),j);
            Ca(p(2),j)=temp;
        end
        Ca(:,1)=Sortf(:,i); %保留克隆源个体
        Calen = zeros(1,Nc1);
        for j=1:Nc1
            Calen(j)=luJingChang(D,Ca(:,j),N);
        end
        [SortCalen,Index]=sort(Calen); %克隆抑制，保留亲和度最高的个体
        SortCa=Ca(:,Index);
        af(:,i)=SortCa(:,1);
        alen(i)=SortCalen(1);
    end
    %% 种群刷新,生成另一半样本
    bf = zeros(N,NP/2);
    blen = zeros(1,NP/2);
    for i=1:NP/2
        bf(:,i)=randperm(N); %随机生成初始种群
        blen(i)=luJingChang(D,bf(:,i),N); %计算路径长度
    end   
    f=[af,bf]; %免疫种群与新种群合并
    len=[alen,blen];
    [Sortlen,Index]=sort(len);
    Sortf=f(:,Index);
    trace(gen)=Sortlen(1);
end

%% 输出优化结果
Bestf=Sortf(:,1); %最优变量
Bestlen=trace(end)%最优值

figure(1) %图1
for i=1:N-1
    plot([C(Bestf(i),1),C(Bestf(i+1),1)],...
    [C(Bestf(i),2),C(Bestf(i+1),2)],'bo-');
    hold on;
end
  
plot([C(Bestf(N),1),C(Bestf(1),1)],...
[C(Bestf(N),2),C(Bestf(1),2)],'ro-');
title(['优化最短距离:',num2str(trace(end))]);

figure(2) %图2
plot(trace,'LineWidth',1.5)
xlabel('迭代次数')
ylabel('目标函数值')
title('亲和度进化曲线')

%% 计算路径长度

function len=luJingChang(D,f,N)
%计算路径长度
%输入城市距离矩阵D，路线f，节点个数N
%输出遍历长度
%测试环境MATLAB2018b

len=D(f(N),f(1));
for i=1:(N-1)
    len=len+D(f(i),f(i+1));
end
end

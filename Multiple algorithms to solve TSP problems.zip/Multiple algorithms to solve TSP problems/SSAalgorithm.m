 %%  SSA algorithm
clear;
clc;
%% 计算城市间相互距离
citys=[1304,2312;3639,1315;4177,2244;3712,1399;3488,1535;
     3326,1556;3238,1229;4196,1044;4312,790;  4386,570  ;
     3007,1970;2562,1756;2788,1491;2381,1676;1332,695  ;
     3715,1678;3918,2179;4061,2370;3780,2212;3676,2578;
     4029,2838;4263,2931;3429,1908;3507,2376;3394,2643;
     3439,3201;2935,3240;3140,3550;2545,2357;2778,2826;
     2370,2975];     %城市坐标
n=size(citys,1);
D=zeros(n,n);
for i=1:n
    for j=i+1:n
        D(i,j)=sqrt(sum((citys(i,:)-citys(j,:)).^2));
        D(j,i)=D(i,j);
    end
end
%%4 初始化参数
ST=0.8;    %预警阈值
m=50;       %麻雀种群数量
popn=m;
pop=zeros(m,n);
PD_percent=0.2;   
SD_percent=0.2;      
genmax=1000;       %最大迭代次数
gen=1;
fitness=zeros(m,1);             %适应度函数值
Pbest=zeros(m,n);               %个体极值路径
Pbest_fitness=zeros(m,1);       %个体极值
Gbest=zeros(genmax,n);          %群体极值路径
Gbest_fitness=zeros(genmax,1);  %群体极值记录
Length_ave=zeros(genmax,1);     %各代路径的平均长度
%% 5产生随机麻雀种群
% 随机产生麻雀位置
for i=1:m
    pop(i,:)=randperm(n);
end
% 计算适应度函数值
for i=1:m
    for j=1:n-1
        fitness(i)=fitness(i) + D(pop(i,j),pop(i,j+1));
    end
        fitness(i)=fitness(i) + D(pop(i,end),pop(i,1));
end
% 极端值
% Pbest_fitness=fitness;   %进行预分配
% Pbest=pop;
% [Gbest_fitness(1),min_index]=min(fitness);
% Gbest(1,:)=pop(min_index,:);
PDn=round(PD_percent*popn);    %捕食者个数
SDn=round(SD_percent*popn);    %预警者的个数
while   gen<=genmax
   [~,sortindex]=sort(fitness);  %对麻雀的适应度升序排列，为了更好的找到发现者与跟随者
   fitness_new=fitness; 
   pop_new=pop;
   [fmax,worse]=max(fitness);   %找到最差位置
   pop_worst=pop(worse,:);
   [fmin,best]=min(fitness);    %找到最佳的位置
   pop_best=pop(best,:);
   if rand<ST          %根据预警值判断位置变换
        for i=1:PDn
           a=sortindex(i);
           r=exp(-i/(rand*genmax));
           if rand<=r    %距离近，保持不动
             pop_new(a,:)=pop_new(a,:);
           else
             dim=round(0.2*m);
             pop_new(a,:)=position_change_little(pop(a,:),dim);
           end
        end
    else
        for i=1:PDn
            a=sortindex(i);
            dim=round(rand*m);
            pop_new(a,:)=position_change_little(pop(a,:),dim); 
        end
   end
    fitness_new=fobi_compute(pop_new,D);   %得到新的函数值
    [~,best2]=min(fitness_new);  %找到更新后的值
    pop_best2=pop(best2,:);    %找到最好的位置二
   % 跟随者位置更新
    for i=PDn+1:popn
           a=sortindex(i);
       if i>0.5*popn
           pop_new(a,:)=randperm(n);   %十分饥饿，自寻食物
       else
             change1=position_minus_position(pop_best2,pop_new(a,:));  %记录最好位置到当前位置变换 
             change1=constant_times_velocity(rand,change1);
             pop_new(a,:)=position_plus_velocity(pop_new(a,:),change1);        
       end
    end
    
    fitness_new=fobi_compute(pop_new,D);    %得到新的函数值
    eta=10e-8;
    index=randperm(popn,SDn);  %随机分配预警者 
     
    for i=1:SDn  
        a=index(i);
        if   fitness(a)>fmin
             change1=position_minus_position(pop_best,pop_new(a,:));  %记录最好位置到当前位置变换 
             change1=constant_times_velocity(rand,change1);
             pop_new(a,:)=position_plus_velocity(pop_new(a,:),change1);        %向着中心位置靠拢
        else
             dim=1;
             pop_new(a,:)=position_change_little(pop(a,:),dim);  %中心位置内，小变动
        end   
    end
     fitness_new=fobi_compute(pop_new,D);      %当前函数最佳值
     index=find(fitness_new<fitness);  %两者相互比较，找到最小的
     fitness(index,:)=fitness_new(index);
     pop(index,:)=pop_new(index,:);
     [fmin,best]=min(fitness);    %找到最佳的位置
     Convergence_curve(gen)=fmin;
     result=pop(best,:);
     gen=gen+1;
end

Shortest_Route=result;  Shortest_Length=min(Convergence_curve);
figure(1)
plot([citys(Shortest_Route,1);citys(Shortest_Route(1),1)],...
     [citys(Shortest_Route,2);citys(Shortest_Route(1),2)],'o-');
grid on
for i = 1:size(citys,1)
    text(citys(i,1),citys(i,2),['   ' num2str(i)]);
end
text(citys(Shortest_Route(1),1),citys(Shortest_Route(1),2),'       起点');
text(citys(Shortest_Route(end),1),citys(Shortest_Route(end),2),'       终点');
xlabel('城市位置横坐标')
ylabel('城市位置纵坐标')
title(['SSA算法优化路径(最短距离:' num2str(Shortest_Length) ')'])
figure(2)
plot(Convergence_curve,'LineWidth',1.5);
disp(['最短距离:' num2str(Shortest_Length)]);
disp(['最短路径:' num2str([Shortest_Route Shortest_Route(1)])]);



function change=position_minus_position(best,pop)
  %记录将pop变成best的交换序列
for i=1:size(best,1)
    for j=1:size(best,2)
        change(i,j)=find(pop(i,:)==best(i,j));
        temp=pop(i,j);
        pop(i,j)=pop(i,change(i,j));
        pop(i,change(i,j))=temp;
    end
end
end

function  change_little=position_change_little(pop,dim)
  %对位置进行晓得变动
  n=size(pop,2);
  for i=1:dim
      a=randperm(n,1);
      b=randperm(n,1);
      tempt=pop(:,a);
      pop(:,a)=pop(:,b);
      pop(:,b)=tempt;  
  end
     change_little=pop;
end

function  fobj=fobi_compute(pop,D)
    m=size(pop,1);  n=size(D);
    fitness=zeros(m,1);     
    for i=1:m
        for j=1:n-1
            fitness(i)=fitness(i) + D(pop(i,j),pop(i,j+1));
        end
            fitness(i)=fitness(i) + D(pop(i,end),pop(i,1));
    end
    fobj=fitness;
end

function change = constant_times_velocity(constant,change)
% 以一定概率保留交换序列
for i=1:size(change,1)
    for j=1:size(change,2)
        if rand>constant
            change(i,j)=0;
        end
    end
end
end

function pop = position_plus_velocity(pop,v)
%利用速度记录的交换序列进行位置修正
for i=1:size(pop,1)
    for j=1:size(pop,2)
        if v(i,j)~=0
            temp=pop(i,j);
            pop(i,j)=pop(i,v(i,j));
            pop(i,v(i,j))=temp;
        end
    end
end
end

